# Ocorrencias-Aeronauticas

Projeto para a cadeira de Classificação e Pesquisa de Dados - UFRGS 2016/2
