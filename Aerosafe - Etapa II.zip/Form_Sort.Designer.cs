﻿namespace Ocorrências_Aeronáuticas
{
    partial class Form_Sort
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnSortGo = new System.Windows.Forms.Button();
            this.comboAlgoritmos = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboCampo = new System.Windows.Forms.ComboBox();
            this.textBenchmarks = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Algoritmo:";
            // 
            // btnSortGo
            // 
            this.btnSortGo.Location = new System.Drawing.Point(289, 81);
            this.btnSortGo.Name = "btnSortGo";
            this.btnSortGo.Size = new System.Drawing.Size(67, 32);
            this.btnSortGo.TabIndex = 2;
            this.btnSortGo.Text = "Go";
            this.btnSortGo.UseVisualStyleBackColor = true;
            this.btnSortGo.Click += new System.EventHandler(this.btnSortGo_Click);
            // 
            // comboAlgoritmos
            // 
            this.comboAlgoritmos.FormattingEnabled = true;
            this.comboAlgoritmos.Items.AddRange(new object[] {
            "Bubble Sort (BBST)",
            "Heap Sort (HPST)",
            "Insertion Sort com Busca Binária (ISBB)",
            "Insertion Sort com Busca Linear (ISBL)",
            "Merge Sort (MGST)",
            "Quick Sort Randomizado (QSRM)",
            "Radix Sort MSD (RMSD) ",
            "Shell Sort (SHST)"});
            this.comboAlgoritmos.Location = new System.Drawing.Point(15, 29);
            this.comboAlgoritmos.Name = "comboAlgoritmos";
            this.comboAlgoritmos.Size = new System.Drawing.Size(223, 21);
            this.comboAlgoritmos.Sorted = true;
            this.comboAlgoritmos.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Campo a ser ordenado:";
            // 
            // comboCampo
            // 
            this.comboCampo.FormattingEnabled = true;
            this.comboCampo.Items.AddRange(new object[] {
            "codigo_ocorrencia",
            "localidade"});
            this.comboCampo.Location = new System.Drawing.Point(15, 81);
            this.comboCampo.Name = "comboCampo";
            this.comboCampo.Size = new System.Drawing.Size(223, 21);
            this.comboCampo.TabIndex = 5;
            // 
            // textBenchmarks
            // 
            this.textBenchmarks.Location = new System.Drawing.Point(15, 132);
            this.textBenchmarks.Multiline = true;
            this.textBenchmarks.Name = "textBenchmarks";
            this.textBenchmarks.ReadOnly = true;
            this.textBenchmarks.Size = new System.Drawing.Size(341, 112);
            this.textBenchmarks.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Benchmarks:";
            // 
            // Form_Sort
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 256);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBenchmarks);
            this.Controls.Add(this.comboCampo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboAlgoritmos);
            this.Controls.Add(this.btnSortGo);
            this.Controls.Add(this.label1);
            this.Name = "Form_Sort";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form_Sort";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSortGo;
        private System.Windows.Forms.ComboBox comboAlgoritmos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboCampo;
        private System.Windows.Forms.TextBox textBenchmarks;
        private System.Windows.Forms.Label label3;
    }
}