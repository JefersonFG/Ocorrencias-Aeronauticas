# Ocorrencias-Aeronauticas

Projeto para a cadeira de Classificação e Pesquisa de Dados - UFRGS 2016/2

# Instruções para compilar / lançar o código fonte

Para compilar o código, abra a solução com o Visual Studio e instale os seguintes plugins:

https://www.nuget.org/packages/CSharpTest.Net.BPlusTree/2.12.810.409
https://www.nuget.org/packages/CSharpTest.Net.Library/
https://www.nuget.org/packages/CsvHelper/
https://www.nuget.org/packages/protobuf-net/

Com os plugins instalados, compile e execute o código em modo debug para utilizá-lo.
